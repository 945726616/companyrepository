<template>
  <div id="app">
    <router-view/>
  </div>
</template>

<script>
export default {
  name: 'app'
}
</script>

<style>
body{
  padding: 0;
  margin: 0;
  box-sizing: border-box;
}
</style>
