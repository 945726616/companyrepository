<template>
  <div>login</div>
</template>
<script>
export default {
  components: {},
  data () {
    return {}
  },
  mounted () {

  },
  methods: {}
}
</script>
<style lang="scss" scoped>
</style>
